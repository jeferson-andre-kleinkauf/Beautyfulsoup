import requests
from bs4 import BeautifulSoup

link  = "https://www.google.com/search?q=pre%C3%A7o+da+soja"
headers = {"User-Agent" : "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36"}

requisicao = requests.get(link, headers=headers)
print(requisicao)
#print(requisicao.text)
site = BeautifulSoup(requisicao.text, "html.parser")
#print(site.prettify())

titulo = site.find("title")
print(titulo)

cocamarhoje = site.find_all("input")
print(cocamarhoje[1])

oleodesoja = site.find("button", class_="Tg7LZd")
print(oleodesoja)

oleodesojaa = site.find("span", class_="kpshf")
print(oleodesojaa)